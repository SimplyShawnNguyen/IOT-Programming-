<script setup lang="ts">

</script>

<template>
    <div class="border-red-200 bg-red-50 flex items-center space-x-4 px-4 py-2 rounded border my-4">
        <IconsAlertTriangle class="h-5 w-5 text-red-600" />
        <div class="flex flex-col">
            <h2 class="text-red-800 text-lg font-semibold">
                Warning: Bin Tilted!
            </h2>
            <p class="text-red-700">
                The trash bin has been tilted or knocked over. Please check the bin status.
            </p>
        </div>
    </div>
</template>

<style scoped>

</style>
