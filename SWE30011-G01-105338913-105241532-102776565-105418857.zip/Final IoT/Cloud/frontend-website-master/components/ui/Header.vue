<script setup lang="ts">

</script>

<template>
    <div>
        <h1 class="text-3xl font-bold text-gray-900">
            Smart Bin Dashboard
        </h1>
        <p class="text-gray-600">
            Real-time monitoring and control
        </p>
    </div>
</template>

<style scoped>

</style>
