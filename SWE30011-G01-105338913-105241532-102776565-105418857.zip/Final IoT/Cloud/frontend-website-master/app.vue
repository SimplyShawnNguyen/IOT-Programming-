<template>
    <div class="min-h-screen p-4 bg-gray-50">
        <NuxtPage />
    </div>
</template>
